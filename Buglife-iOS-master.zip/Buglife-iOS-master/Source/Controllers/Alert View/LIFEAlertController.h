//
//  LIFEContainerAlertToImageEditorAnimator.m
//  Copyright (C) 2017-2018 Buglife, Inc.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//
//

#import <UIKit/UIKit.h>

@class LIFEAlertView;
@class LIFEAlertAction;

@interface LIFEAlertController : UIViewController

@property (nonnull, nonatomic, readonly) LIFEAlertView *alertView;
@property (nullable, nonatomic, readonly) NSLayoutConstraint *alertViewWidthConstriant;

+ (nonnull instancetype)alertControllerWithTitle:(nullable NSString *)title message:(nullable NSString *)message preferredStyle:(UIAlertControllerStyle)preferredStyle;

- (void)setImage:(nullable UIImage *)image;
- (void)addAction:(nonnull LIFEAlertAction *)action;
- (void)setDarkOverlayHidden:(BOOL)hidden;
- (void)prepareExpandToDismissTransition;

@end
